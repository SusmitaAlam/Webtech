
<?php  
require_once '../models/model.php';
 
 
if (isset($_POST['createUser'])) {
    $data['email'] = $_POST['email'];
    $data['username'] = $_POST['username'];
    $data['password'] = $_POST['password'];
    $data['gender'] = $_POST['gender'];
    $data['dob'] = $_POST['dob'];
    
 
 
 
  if (addUser($data)) {

   
    session_start();
    $_SESSION['success_message'] = 'Successfully added!!';
    header("location:../views/register.php");
   
    
  }
} 
else {
    echo 'You are not allowed to access this page.';
}
 
?>