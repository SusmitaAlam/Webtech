<?php

require_once('../models/model.php');

if (isset($_POST['login'])) {
   
    $data['username'] = $_POST['username'];
    $data['password'] = $_POST['password'];
   
	$res=auth($data);

if($res)
{
	session_start();
	$_SESSION['username']=$data['username'];
   header("location:../views/dash.php");
echo "successfully login";
}
else
{
	header("location:../views/login.php");
}
}
    

?>