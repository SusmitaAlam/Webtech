
<?php 
//db
$serverName    ="localhost";
$userName      ="root";
$password      ="";
$dbName        ="Susmita";
$conn          =new mysqli($serverName,$userName,$password,$dbName);
//db end

$sql2          ="select * from inventory";
$res2          =mysqli_query($conn,$sql2);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Inventory</title>
  <style>
    body {
     
    }
    table {
      
    }
    th, td {
        border: 1px solid #333;
      padding: 10px;
      text-align: left;
    }
   
    
   
  </style>
</head>
<body>
  <table>
    <head>
      <tr class="inventory-header-row">
        <th colspan="4">Inventory</th>
      </tr>
      <tr>
        <th>Product Serial</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Price per Unit</th>
      </tr>
    </head>
    <?php while($res3=mysqli_fetch_assoc($res2)){ ?>
<tr>
<td><?php echo $res3["Product Serial"]; ?></td>
<td><?php echo $res3["Product Name"]; ?></td>
<td><?php echo $res3["Quantity"]; ?></td>
<td><?php echo $res3["Price per Unit"]; ?></td>
</tr>
<?php } ?>
    
  </table>
</body>
</html>
