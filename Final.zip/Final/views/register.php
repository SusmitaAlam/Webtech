<?php
session_start();
?>
<!DOCTYPE html>
<html>
 
<head>
    <title>Registration</title>
    <style type="text/css">
        
        .error {
            color: red;
        }
    </style>
    
<link rel="stylesheet" type="text/css" href="style.css" />

    <?php
if(isset($_SESSION['success_message'])) {
    echo "<p>{$_SESSION['success_message']}</p>";
    unset($_SESSION['success_message']); 
}
?>

   
<script>
        function validateform() {
            
            var email = document.getElementById("email").value;
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;
            var confirmpassword = document.getElementById("confirmpassword").value;
            var gender = document.getElementById("gender").value;
            var dob = document.getElementById("dob").value;
 
            var pattern = /^([a-zA-Z0-9\._]+)@([a-zA-Z0-9])+.([a-z]+)(.[a-z]+)?$/
            var username_pattern = /^[a-zA-Z-'_]*$/
            var password_pattern = /[@, #, $,%]/
 
 
           
 
            if (email == '') {
                alert("email cannot be empty ");
                return false;
            }
            if (!email.match(pattern)) {
                alert("email is invalid");
                return false;
            }
 
            if (username == '') {
                alert("username cannot be empty");
                return false;
            }
            
            
            if (!username.match(username_pattern)) {
                alert("username must have letters and underscore ");
                return false;
            }
 
            if (password == '') {
                alert("password cannot be empty");
                return false;
            }
            if (username.length < 5) {
                alert("username must not be less than five (5) characters");
                return false;
            }
            if (!password.match(password_pattern)) {
                alert("password must contain at least one of the special characters (@, #, $,%)");
                return false;
            }
            if (confirmpassword == '') {
                alert("confirmpassword cannot be empty");
                return false;
            }
            if (password != confirmpassword) {
                alert("password does not match to the new password");
                return false;
            }
            if (gender == '') {
                alert("gender cannot be empty");
                return false;
            }
            if (dob == '') {
                alert("date of birth cannot be empty");
                return false;
            }
 
 
        }
    </script>
</head>
 

<body>
    <br />
    
 
    <div class="container" style="width:500px;">
       
        
        <form action="../controllers/createUser.php" method="post" onsubmit="return validateform()">
            <?php
            if (isset($error)) {
                echo $error;
            }
            ?>
            <br />
            <h3>REGISTRATION</h3><br/>
            
            <label>E-mail</label>
            <input style="margin-bottom :10px;"  type="text" name="email" id="email"  value="" />
 
            </br>
            <label>User Name</label>
            <input  style="margin-bottom :10px;" type="text" name="username" id="username"  value="" />
 
            </br>
            <label>Password</label>
            <input  style="margin-bottom :10px;"  type="password" name="password" id="password" />
 
            </br>
            <label>Confirm Password</label>
            <input  style="margin-bottom :10px;" type="password" name="confirmpassword" id="confirmpassword"  />
 
            <br>
 
            <fieldset>
                <legend>Gender</legend>
                <input  style="margin-bottom :10px;" type="radio" id="gender" name="gender" value="male">
                <label for="male">Male</label>
                <input  style="margin-bottom :10px;" type="radio" id="gender" name="gender" value="female">
                <label for="female">Female</label>
                <input  style="margin-bottom :10px;" type="radio" id="gender" name="gender" value="other">
                <label for="other">Other</label>
 
                </br>
                <legend>Date of Birth:</legend>
                <input  style="margin-bottom :10px;" type="date" name="dob" id="dob">
 
                </br>
            </fieldset>
 
            <input style="margin-bottom :10px;"  type="submit" name="createUser" value="Register"  /><br />
 
            <?php
            if (isset($message)) {
                echo $message;
            }
            ?>
            <p>Already have an account? <a href="login.php">login now</a></p>
        </form>
    </div>
    <br />
</body>
 
</html>