<?php
// Database connection
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "Susmita";
$conn = new mysqli($serverName, $userName, $password, $dbName);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $newPassword = $_POST['new_password'];
    $retypePassword = $_POST['retype_password'];

    
    if ($newPassword !== $retypePassword) {
        echo "New password and retype password do not match";
    } else {
        
    

        
        $sql = "UPDATE user_info SET password = '$newPassword' WHERE email = '$email'"; // Change 'id' to match your admin record
        if ($conn->query($sql) === TRUE) {
            echo "Password updated successfully";
        } else {
            echo "Error updating password: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
    <title>Change Password</title>
</head>
<body>
<div class="container" style="width:500px;">
    
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <h1>Change Password</h1>
        Email <input  style="margin-bottom :10px;" type="text" name="email"><br>
        New Password: <input  style="margin-bottom :10px;" type="password" name="new_password"><br>
        Retype Password: <input  style="margin-bottom :10px;" type="password" name="retype_password"><br>
        <button type="submit">Submit</button>
        <p>Go to login  <a href="login.php">Login</a></p>
    </form>
</div>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
