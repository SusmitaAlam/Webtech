<?php 
session_start();
if(empty($_SESSION['username'])){
header("location:login.php");
}
else if(isset($_GET['out']))
{
	session_destroy();
	header("location:login.php");

}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<div class="container" style="width:500px;">


<form>
<h3>Welcome To <?php echo $_SESSION['username'];?></h3></br>
<button  style="margin-bottom :10px;" name="">Resturant</button></br>
<button  style="margin-bottom :10px;" name="">Location</button></br>
<button  style="margin-bottom :10px;" name="">Branch</button></br>
<button  style="margin-bottom :10px;" name="">Offer</button></br>
<button  style="margin-bottom :10px;" name="">Complain</button></br>
<button  style="margin-bottom :10px;"  name="out">LogOut</button>

<p>contact with us  <a href="">Helpline</a></p>
</form>
</div>
</body>
</html>