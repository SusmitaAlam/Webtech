<!DOCTYPE html>
<html>
<head>


<title>LOGIN</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <div class="container" style="width:500px;"> 
        
<form method="post" action="../controllers/logCheckController.php">
<h3>LOGIN</h3>
User Name:<input style="margin-bottom :10px;" type="text" name="username"><br>
Password:<input  style="margin-bottom :10px;" type="text" name="password"><br>
<input type="submit" name="login" value="Login"  /><br />
<p>Can't remember the password <a href="changepass.php">Forget password</a></p>
 
<p>Doesn't have any account? <a href="register.php">Registration now</a></p>
</form>
</div>
</body>
</html>