
<?php
 
require_once 'DB.php';
function addUser($data)
{
    $conn = db_conn();
    $selectQuery = "INSERT into user_info (email, username, password,gender,dob)
VALUES (:email, :username, :password, :gender, :dob)";
    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            ':email' => $data['email'],
            ':username' => $data['username'],
            ':password' => $data['password'],
            ':gender' => $data['gender'],
            ':dob' => $data['dob'],
            
        ]);

    } catch (PDOException $e) {
        echo $e->getMessage();
    }
 
    $conn = null;
    return true;
}


function auth($data)

{
    $conn = db_conn();
    $selectQuery = "SELECT username , password FROM user_info where Username =:username and Password=:password";
 
    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            ':username' => $data['username'],
            ':password' => $data['password']
        ]);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    return $row;
}

